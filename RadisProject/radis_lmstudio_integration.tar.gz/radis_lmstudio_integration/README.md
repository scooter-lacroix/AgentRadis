# RadisProject with LM Studio Integration

This integration allows RadisProject to work seamlessly with LM Studio, providing
a direct connection to LM Studio's API for language model inference.

## Requirements

- RadisProject installed
- LM Studio running with a loaded model
- Python 3.8 or newer
- Required Python packages: requests

## Installation

This installation has been automated for you. The installer has:

1. Created a new `app/llm/lm_studio_direct.py` file with the LM Studio client
2. Created a `run_radis_lmstudio.py` script for easy execution

## Usage

### Basic Usage

```bash
# Run with a specific prompt
./run_radis_lmstudio.py "What is the meaning of life?"

# Run in interactive mode
./run_radis_lmstudio.py
```

### Advanced Options

```bash
# Specify a different model (must be loaded in LM Studio)
./run_radis_lmstudio.py --model "llama-3-8b" "Tell me about Mars"

# Adjust generation parameters
./run_radis_lmstudio.py --temperature 0.9 --max_tokens 2000 "Write a short story"

# Enable debug logging
./run_radis_lmstudio.py --debug "What's the capital of France?"
```

## How It Works

This integration:

1. **Direct API Connection**: Uses the `/v1/chat/completions` endpoint of LM Studio
2. **RadisAgent Integration**: Connects with the RadisAgent framework
3. **Interactive Mode**: Provides an easy-to-use command-line interface

## Troubleshooting

### Common Issues

**Error: Connection Refused**
- Ensure LM Studio is running
- Check that the default port (1234) is correct

**Empty or Unexpected Responses**
- Ensure a model is loaded in LM Studio
- Try decreasing max_tokens if responses are cut off

**Slow Response Times**
- This is normal for large models on consumer hardware
- Consider using a smaller model or adjusting parameters in LM Studio

## Configuration

You can modify the default settings in the `run_radis_lmstudio.py` script:

- Default model: Currently set to "qwen2.5-7b-instruct-1m"
- Default temperature: 0.7
- Default max_tokens: 1000

## Technical Details

The integration uses a direct HTTP client approach rather than the OpenAI
library because of compatibility issues with the LM Studio API. This ensures
reliable operation regardless of API changes in LM Studio.
