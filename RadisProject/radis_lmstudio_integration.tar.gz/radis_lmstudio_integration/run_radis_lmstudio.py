#!/usr/bin/env python3
"""
RadisLMStudio Runner

A script that runs RadisProject with direct LM Studio integration,
bypassing any problematic API layers.
"""

import argparse
import asyncio
import logging
import os
import sys

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("radis_lmstudio")

def parse_args():
    """Parse command-line arguments"""
    parser = argparse.ArgumentParser(description="RadisLMStudio Runner")
    parser.add_argument(
        "prompt", nargs="?", default=None, help="Initial prompt (optional)"
    )
    parser.add_argument(
        "--debug", action="store_true", help="Enable debug logging"
    )
    parser.add_argument(
        "--model", default="qwen2.5-7b-instruct-1m", 
        help="Model name to use in LM Studio"
    )
    parser.add_argument(
        "--temperature", type=float, default=0.7,
        help="Temperature for text generation (0.0-1.0)"
    )
    parser.add_argument(
        "--max_tokens", type=int, default=1000,
        help="Maximum number of tokens to generate"
    )
    return parser.parse_args()

def print_banner():
    """Print the RadisLMStudio banner"""
    print("\n" + "=" * 39)
    print("           Starting AgentRadis")
    print("=" * 39 + "\n")

async def run_radis_agent(prompt, config):
    """Run the Radis agent with the given prompt"""
    try:
        # Import the necessary modules
        from app.agent.radis import RadisAgent
        from app.llm.lm_studio_direct import LMStudioDirect
        
        # Create the LM Studio client
        lm_studio = LMStudioDirect(config)
        
        # Initialize the RadisAgent
        agent = RadisAgent()
        
        # Set up the agent
        await agent.async_setup()
        
        # Process the prompt
        print("\nI'm composing a thorough response for you...")
        
        # Use the direct LM Studio client to generate a response
        response = lm_studio.generate(prompt)
        
        print(f"\nResponse from LM Studio:\n\n{response}\n")
        
        return True
        
    except Exception as e:
        logger.error(f"Error running RadisAgent: {e}")
        import traceback
        traceback.print_exc()
        return False

async def main_async():
    """Async main entry point"""
    args = parse_args()
    
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
        
    # Set up the configuration
    config = {
        "api_base": "http://127.0.0.1:1234",
        "model": args.model,
        "temperature": args.temperature,
        "max_tokens": args.max_tokens,
    }
        
    # Print the banner
    print_banner()
    
    # Process initial prompt if provided
    if args.prompt:
        await run_radis_agent(args.prompt, config)
    else:
        # Enter interactive loop
        print("\nInteractive mode. Type 'exit' to quit.\n")
        
        while True:
            try:
                prompt = input("\nEnter your query: ")
                if prompt.lower() in ["exit", "quit"]:
                    print("Goodbye!")
                    break
                    
                await run_radis_agent(prompt, config)
                
            except KeyboardInterrupt:
                print("\n\nExiting due to keyboard interrupt.")
                break
            except Exception as e:
                logger.error(f"Error: {e}")
                print(f"\nRadis: I encountered an error processing your request: {e}\n")

def main():
    """Main entry point"""
    asyncio.run(main_async())

if __name__ == "__main__":
    main()
