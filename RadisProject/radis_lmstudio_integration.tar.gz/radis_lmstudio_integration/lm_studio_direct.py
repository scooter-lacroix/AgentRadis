"""
LM Studio Direct Client

A direct HTTP client for LM Studio that bypasses the OpenAI library
and uses raw HTTP requests to communicate with the server.
"""

import json
import logging
import requests
import time
from typing import Any, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

class LMStudioDirect:
    """
    Direct HTTP client for LM Studio's inference API.
    This client uses direct HTTP requests to LM Studio's chat completions endpoint.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize the direct LM Studio client"""
        self.config = config or {}
        
        # Extract configuration
        self.api_base = self.config.get("api_base", "http://127.0.0.1:1234").rstrip("/")
        self.model = self.config.get("model", "gemma-3-4b-it")
        self.temperature = float(self.config.get("temperature", 0.7))
        self.max_tokens = int(self.config.get("max_tokens", 1000))
        self.timeout = float(self.config.get("timeout", 120.0))
        
        # Set the endpoint URL
        self.endpoint = f"{self.api_base}/v1/chat/completions"
        
        logger.info(f"Initialized LM Studio Direct client with endpoint: {self.endpoint}")
    
    def generate(self, prompt: str) -> str:
        """
        Generate a completion for the given prompt.
        
        Args:
            prompt: The input prompt
            
        Returns:
            The generated text
        """
        # Create a messages array with the user prompt
        messages = [{"role": "user", "content": prompt}]
        
        # Call the chat endpoint
        return self.generate_from_messages(messages)
    
    def generate_from_messages(self, messages: List[Dict[str, str]]) -> str:
        """
        Generate a completion from a list of messages.
        
        Args:
            messages: List of message dictionaries with 'role' and 'content'
            
        Returns:
            The generated text
        """
        try:
            # Prepare the request data
            data = {
                "model": self.model,
                "messages": messages,
                "temperature": self.temperature,
                "max_tokens": self.max_tokens
            }
            
            logger.info(f"Sending request to LM Studio: {self.endpoint}")
            logger.debug(f"Request data: {data}")
            
            # Send the request
            start_time = time.time()
            response = requests.post(
                self.endpoint,
                json=data,
                timeout=self.timeout
            )
            duration = time.time() - start_time
            
            logger.info(f"Response received in {duration:.2f}s (status: {response.status_code})")
            
            # Parse the response
            if response.status_code == 200:
                response_data = response.json()
                
                # Check if there's an error message
                if "error" in response_data:
                    error_msg = response_data["error"]
                    logger.warning(f"LM Studio error: {error_msg}")
                    return f"I encountered an error: {error_msg}"
                
                # Extract the completion text
                if "choices" in response_data and response_data["choices"]:
                    completion = response_data["choices"][0]["message"]["content"]
                    return completion
                else:
                    logger.warning(f"No choices in response: {response_data}")
                    return "I received an empty response from the language model."
            else:
                logger.error(f"Error response: {response.status_code} {response.text}")
                return f"I received an error response from the language model: {response.status_code}"
                
        except requests.exceptions.Timeout:
            logger.error("Request timed out")
            return "I'm sorry, but the request to the language model timed out. Please try again later."
            
        except Exception as e:
            logger.error(f"Error in generate_from_messages: {e}")
            return f"I encountered an error while generating a response: {e}"
