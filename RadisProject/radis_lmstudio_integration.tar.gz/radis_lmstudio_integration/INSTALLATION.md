# Installation Instructions

1. Extract this directory to your RadisProject root directory
2. Run the installation script:

```bash
./install_radis_lmstudio.sh
```

3. Ensure LM Studio is running with a model loaded
4. Run the integration:

```bash
./run_radis_lmstudio.py "Your prompt here"
```

For more details, see README.md after installation.
